package InvetoryApp;

import android.app.Activity;  // Import the Activity class
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class PermissionUtils {

    /**
     * Check if a specific permission is granted.
     *
     * @param context     The context from which the check is being made.
     * @param permission  The permission you want to check.
     * @return true if the permission is granted, false otherwise.
     */
    public static boolean isPermissionGranted(Context context, String permission) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED;
        } else {
            // For devices running versions below Marshmallow, permissions are granted at install time
            return true;
        }
    }

    /**
     * Request a specific permission.
     *
     * @param activity    The activity requesting the permission.
     * @param permission  The permission to request.
     * @param requestCode The request code to handle the result.
     */
    public static void requestPermission(Activity activity, String permission, int requestCode) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ActivityCompat.requestPermissions(activity, new String[]{permission}, requestCode);
        }
    }

    /**
     * Handle the result of a permission request.
     *
     * @param requestCode The request code passed in `requestPermissions()`.
     * @param permissions The requested permissions.
     * @param grantResults The grant results for the corresponding permissions.
     * @return true if permission was granted, false otherwise.
     */
    public static boolean handlePermissionResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
    }
}