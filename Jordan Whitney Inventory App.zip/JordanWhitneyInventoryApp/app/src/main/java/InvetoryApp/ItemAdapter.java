package InvetoryApp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.jordanwhitneyinventoryapp.R;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {

    private final List<Item> itemList;  // List of Item objects
    private final OnDeleteClickListener deleteClickListener;  // Listener for delete button click

    // Interface for handling delete button clicks
    public interface OnDeleteClickListener {
        void onDeleteClick(int itemId);  // Method to handle delete click with item ID
    }

    // Constructor to initialize the list and listener
    public ItemAdapter(List<Item> itemList, OnDeleteClickListener deleteClickListener) {
        this.itemList = itemList;
        this.deleteClickListener = deleteClickListener;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the item layout for each item in the RecyclerView
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.inventory_grid_item, parent, false);
        return new ItemViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        // Bind data to the ViewHolder
        Item currentItem = itemList.get(position);  // Get the current item at this position
        holder.bind(currentItem);  // Bind the item data to the ViewHolder
    }

    @Override
    public int getItemCount() {
        return itemList.size();  // Return the size of the list
    }

    // ViewHolder class to hold views for each item
    class ItemViewHolder extends RecyclerView.ViewHolder {

        private final TextView itemNameTextView;
        private final TextView itemQuantityTextView;
        private final Button deleteButton;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            // Initialize the views in the item layout
            itemNameTextView = itemView.findViewById(R.id.item_name_text_view);
            itemQuantityTextView = itemView.findViewById(R.id.item_quantity_text_view);
            deleteButton = itemView.findViewById(R.id.delete_button);
        }

        // Method to bind the data from the Item object to the views
        public void bind(Item item) {
            // Set the item name and quantity in the respective TextViews
            itemNameTextView.setText(item.getName());
            itemQuantityTextView.setText(String.valueOf(item.getQuantity()));

            // Set up the delete button functionality
            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Trigger the delete action when the delete button is clicked
                    if (deleteClickListener != null) {
                        deleteClickListener.onDeleteClick(item.getId());  // Pass item ID to listener
                    }
                }
            });
        }
    }
}