package InvetoryApp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.zybooks.jordanwhitneyinventoryapp.R;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView inventoryRecyclerView;
    private ItemAdapter itemAdapter;
    private InventoryDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventory_grid);

        // Initialize UI components
        inventoryRecyclerView = findViewById(R.id.inventory_recycler_view);
        Button addItemButton = findViewById(R.id.add_item_button);

        // Initialize database helper
        dbHelper = new InventoryDatabaseHelper(this);

        // Set up RecyclerView
        inventoryRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        // Load inventory data and set up adapter
        loadInventoryData();

        // Set up add item button functionality
        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAddItemScreen();
            }
        });
    }

    /**
     * Load inventory data from the database and update the RecyclerView.
     */
    private void loadInventoryData() {
        // Make sure this returns a list of Item objects
        List<Item> inventoryList = dbHelper.getAllItems();  // Use Item, not ClipData.Item
        itemAdapter = new ItemAdapter(inventoryList, new ItemAdapter.OnDeleteClickListener() {
            @Override
            public void onDeleteClick(int itemId) {
                deleteItem(itemId);
            }
        });
        inventoryRecyclerView.setAdapter(itemAdapter);
    }

    /**
     * Open the screen to add a new item.
     */
    private void openAddItemScreen() {
        Intent intent = new Intent(MainActivity.this, AddItemActivity.class);
        startActivity(intent);
    }

    /**
     * Delete an item from the database and refresh the RecyclerView.
     *
     * @param itemId The ID of the item to delete.
     */
    private void deleteItem(int itemId) {
        if (dbHelper.deleteItem(itemId)) {
            loadInventoryData();  // Refresh the list after deletion
            Toast.makeText(MainActivity.this, "Item deleted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(MainActivity.this, "Error deleting item", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Close the database helper to avoid memory leaks
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}