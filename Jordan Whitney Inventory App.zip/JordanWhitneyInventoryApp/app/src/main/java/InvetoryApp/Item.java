package InvetoryApp;

public class Item {
    private int id;
    private String name;
    private int quantity;

    // Constructor to initialize Item with id, name, and quantity
    public Item(int id, String name, int quantity) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
    }

    // Getter for ID
    public int getId() {
        return id;
    }

    // Getter for Name
    public String getName() {
        return name;
    }

    // Getter for Quantity
    public int getQuantity() {
        return quantity;
    }

    // Setter for ID (optional, in case you want to change the ID later)
    public void setId(int id) {
        this.id = id;
    }

    // Setter for Name (optional, in case you want to change the name later)
    public void setName(String name) {
        this.name = name;
    }

    // Setter for Quantity (optional, in case you want to change the quantity later)
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // Override toString() to make it easier to print Item objects (for debugging or logging)
    @Override
    public String toString() {
        return "Item{id=" + id + ", name='" + name + "', quantity=" + quantity + "}";
    }
}