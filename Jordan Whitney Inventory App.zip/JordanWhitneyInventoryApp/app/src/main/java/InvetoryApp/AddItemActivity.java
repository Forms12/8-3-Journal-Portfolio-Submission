package InvetoryApp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.jordanwhitneyinventoryapp.R;

public class AddItemActivity extends AppCompatActivity {

    private EditText itemNameEditText;
    private EditText itemQuantityEditText;
    private Button addItemButton;
    private InventoryDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // Initialize views
        itemNameEditText = findViewById(R.id.item_name_edit_text);
        itemQuantityEditText = findViewById(R.id.item_quantity_edit_text);
        addItemButton = findViewById(R.id.add_item_button);

        // Initialize database helper
        dbHelper = new InventoryDatabaseHelper(this);

        // Set up add item button click listener
        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addItem();
            }
        });
    }

    private void addItem() {
        String itemName = itemNameEditText.getText().toString().trim();
        String itemQuantityStr = itemQuantityEditText.getText().toString().trim();

        // Validate input
        if (itemName.isEmpty() || itemQuantityStr.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int itemQuantity = Integer.parseInt(itemQuantityStr);

        // Create new item
        Item newItem = new Item(0, itemName, itemQuantity);

        // Insert item into database
        long id = dbHelper.addItem(newItem);
        if (id != -1) {
            Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
            finish(); // Close the AddItemActivity and return to MainActivity
        } else {
            Toast.makeText(this, "Error adding item", Toast.LENGTH_SHORT).show();
        }
    }
}